r<?php

class MariaDB_dianafile1
{

    public function __construct()
    {
    }
}